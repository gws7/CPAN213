import { StatusBar } from 'expo-status-bar';
import { useState } from 'react';
import { StyleSheet, Text, View, Image, Button, Alert, TextInput } from 'react-native';

export default function App() {
  const showAlert = () => {
    Alert.alert("Character Information: ", `Name: ${name}\nPoints: ${points}`);
  };

  const [name, setName] = useState('');
  const [points, setPoints] = useState('');

  return (
    <View style={styles.container}>
      <View style={styles.column}>
        <Image 
          source={{ uri: 'https://www.pngkey.com/png/full/52-528859_crescent-moon-outline-lua-icon-png.png' }} 
          style={styles.image} 
          resizeMode='contain' 
        />
        <Text style={styles.name}>Welcome to the world of <Text style={styles.worldName}>Lithos</Text></Text>
      </View>

      <Text style={styles.label}>Username:</Text>
      <TextInput 
        style={styles.input} 
        placeholder='Enter your character name' 
        value={name} 
        onChangeText={setName} 
        autoCapitalize='words' 
        maxLength={15} 
      />

      <Text style={styles.label}>Points:</Text>
      <TextInput 
        style={styles.input} 
        placeholder="Enter your character's points" 
        value={points} 
        onChangeText={setPoints} 
        inputMode='numeric' 
        maxLength={2} 
      />

      <Button title="Enter" onPress={showAlert} color={'black'}/>
      <StatusBar style="auto" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f4f8',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  column: {
    alignItems: 'center',
    marginBottom: 30,
  },
  name: {
    marginTop: 10,
    fontSize: 18,
    color: '#333',
    textAlign: 'center',
  },
  worldName: {
    fontWeight: 'bold',
    color: 'darkgreen',
  },
  image: {
    width: 70,
    height: 70,
    marginBottom: 10,
  },
  label: {
    marginBottom: 8,
    color: '#333',
    fontSize: 16,
  },
  input: {
    height: 40,
    borderColor: '#ccc',
    borderWidth: 1,
    paddingLeft: 10,
    marginBottom: 15,
    borderRadius: 8,
    backgroundColor: '#fff',
    width: '80%',
  },
});
