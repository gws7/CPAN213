import { Button, StyleSheet, Text, View } from 'react-native';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';
import globalStyles from "./shared/GlobalStyles";
import HomeScreen from './screens/HomeScreen';

/*

to use React Navigation library
npm install @react-navigation/native

to use expo project with ReactNavigation
npm install react-native-screens react-native-safe-area-context

for Stack navigation
npm install @react-navigation/native-stack

for bottom tab navigation
npm install @react-navigation/bottom-tabs

for icons
npm install --save react-native-vector-icons

*/

export default function App() {
  return (
    <SafeAreaProvider>
    <SafeAreaView style={globalStyles.safeArea}>
    <View style={globalStyles.container}>
      <HomeScreen />
    </View>
    <View style={globalStyles.spacer} />
    </SafeAreaView>
    </SafeAreaProvider>
  );
}
