import { StyleSheet, View, Text, Button, TouchableOpacity } from "react-native"
import globalStyles from "../shared/GlobalStyles";

const HomeScreen = () => {
    return(
        <View style={globalStyles.container}>
            <Text style={globalStyles.headerStyle}>Home Screen</Text>

            <Text style={globalStyles.title}>Welcome </Text>

            <TouchableOpacity
                style = {globalStyles.button}
                onPress={() => {
                    //navigate to About Screen
                }}
            >
                <Text style = {globalStyles.buttonText}>About</Text>
            </TouchableOpacity>

            <TouchableOpacity
                style = {globalStyles.button}
                onPress={() => {
                    //navigate to Contact Screen
                }}
            >
                <Text style = {globalStyles.buttonText}>Contact</Text>
            </TouchableOpacity>

            <TouchableOpacity
                style = {globalStyles.button}
                onPress={() => {
                    //navigate to Tab Navigation Screen
                }}
            >
                <Text style = {globalStyles.buttonText}>Tab Navigation</Text>
            </TouchableOpacity>

        </View>
    )
}

export default HomeScreen;
