
import { StyleSheet, View, Text, TouchableOpacity } from "react-native"
import globalStyles from "../shared/GlobalStyles";

const AboutScreen = () => {
    return(
        <View style={globalStyles.container}>
            <Text style={globalStyles.title}>About Screen</Text>

            <TouchableOpacity
                style = {globalStyles.button}
                onPress={() => {
                    //navigate to Contact Screen
                }}
            >
                <Text style = {globalStyles.buttonText}>Contact</Text>
            </TouchableOpacity>

            <TouchableOpacity
                style = {globalStyles.button}
                onPress={() => {
                    //navigate to first screen
                }}
            >
                <Text style = {globalStyles.buttonText}>Pop To Top</Text>
            </TouchableOpacity>

            <TouchableOpacity
                style = {globalStyles.button}
                onPress={() => {
                     //removes current screen from stack
                }}
            >
                <Text style = {globalStyles.buttonText}>Pop</Text>
            </TouchableOpacity> 

            <TouchableOpacity
                style = {globalStyles.button}
                onPress={() => {
                     //removes current screen from stack and show Contacts screen
                }}
            >
                <Text style = {globalStyles.buttonText}>Pop To Contacts</Text>
            </TouchableOpacity> 

            <TouchableOpacity
                style = {globalStyles.button}
                onPress={() => {
                     //navigate to Previous screen
                }}
            >
                <Text style = {globalStyles.buttonText}>Go Back</Text>
            </TouchableOpacity> 
        </View>
    )
}

export default AboutScreen;
