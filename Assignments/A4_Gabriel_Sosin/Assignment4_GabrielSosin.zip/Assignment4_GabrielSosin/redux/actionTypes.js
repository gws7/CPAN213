export const ADD_TASK = 'ADD_TASK';
export const EDIT_TASK = 'EDIT_TASK';
export const FETCH_TASKS = "FETCH_TASKS";
export const DELETE_TASK = "DELETE_TASK";
