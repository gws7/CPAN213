import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import ParkingListScreen from '../screens/ParkingListScreen';
import AddParkingScreen from '../screens/AddParkingScreen';
import ParkingDetailScreen from '../screens/ParkingDetailScreen';

// Create a stack navigator
const Stack = createNativeStackNavigator();

const AppNavigator = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="ParkingList">
        <Stack.Screen 
          name="ParkingList" 
          component={ParkingListScreen} 
          options={{ title: 'Parking List' }}
        />
        <Stack.Screen 
          name="AddParking" 
          component={AddParkingScreen} 
          options={{ title: 'Add New Parking' }}
        />
        <Stack.Screen 
          name="ParkingDetail" 
          component={ParkingDetailScreen} 
          options={{ title: 'Parking Details' }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

export default AppNavigator;
