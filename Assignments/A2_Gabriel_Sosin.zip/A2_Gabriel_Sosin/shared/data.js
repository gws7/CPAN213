const roomData = [
    { roomNumber: "A101", capacity: 5, available: true },
    { roomNumber: "A102", capacity: 10, available: false },
    { roomNumber: "A103", capacity: 8, available: false },
    { roomNumber: "A104", capacity: 10, available: true },
    { roomNumber: "A105", capacity: 7, available: true }
];

export default roomData;
