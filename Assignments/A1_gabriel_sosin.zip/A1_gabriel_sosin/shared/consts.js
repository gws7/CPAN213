export const COLORS = {
    primary: "#393e41",
    secondary: "#e94f37",
    third: "#f6f7eb"
}