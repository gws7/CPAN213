// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

//import necessary services from Firebase
import {getFirestore} from "firebase/firestore";

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyC_Arn7WiU1Xj3OdIRfXFH6ifaRP0g96PM",
  authDomain: "winter25-1b8a4.firebaseapp.com",
  projectId: "winter25-1b8a4",
  storageBucket: "winter25-1b8a4.firebasestorage.app",
  messagingSenderId: "771539920618",
  appId: "1:771539920618:web:0cec1a3fac2cf4a22a5993"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

export const db = getFirestore(app)