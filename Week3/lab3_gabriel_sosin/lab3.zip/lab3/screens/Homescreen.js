import { Text, View, TouchableOpacity, Image } from "react-native";
import Styles from "../shared/Style";
import Feather from '@expo/vector-icons/Feather';
import FontAwesome5 from '@expo/vector-icons/FontAwesome5';
import MaterialCommunityIcons from '@expo/vector-icons/MaterialCommunityIcons';

const HomeScreen = () => {
    return (
        <View style={{marginTop: 100}}>
            <Image
                source={{ uri: 'https://i.scdn.co/image/ab67616d00001e02f3f7d2ea2ad435b57d6697df' }}
                style={Styles.image}
            />
            <View style={Styles.information}>
                <Text style={Styles.timeStampText}>0:07</Text>
                <Text style={Styles.timeStampText}>3:53</Text>
            </View>
            <View style={Styles.information}>
                <Text style={Styles.timeStampText}>Glimpse Of Us</Text>
                <Feather name="heart" size={24} color="white" />
            </View>
            <View style={[Styles.information, {marginTop: "10%"}]}>
                <MaterialCommunityIcons name="rewind-10" size={40} color="white" />
                <FontAwesome5 name="pause" size={50} color="white" />
                <MaterialCommunityIcons name="fast-forward-10" size={40} color="white" />
            </View>
        </View>
    );
};

export default HomeScreen;
