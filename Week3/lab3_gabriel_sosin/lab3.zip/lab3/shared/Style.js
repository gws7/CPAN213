import { StyleSheet } from "react-native";
import { COLORS } from "./Constants";

const Styles = StyleSheet.create({
    image: {
        width: 300, 
        height: 300,
        resizeMode: "cover",
        borderColor: "white",
        borderWidth: 1,
        marginBottom: 9,
        marginHorizontal: 50,
        borderRadius: 5, 
    },
    information: {
        flexDirection: "row",
        justifyContent: "space-between",
        marginBottom: 20,
        width: "96.5%",
        paddingHorizontal: "15%",

    },
    timeStampText: {
        color: "white",
        fontSize: 17,
        fontWeight: "bold"
    },

});

export default Styles;
