export const COLORS = {
    primary: "#5c1010",
}